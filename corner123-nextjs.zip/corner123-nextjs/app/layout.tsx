import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'CORNER 123 | Wholesale Women\'s Clothing – Los Angeles',
  description: 'CORNER 123 — Premier wholesale women\'s clothing in the Los Angeles Fashion District. Shop hoodies, jackets, dresses, tops, bottoms, and outerwear.',
  openGraph: {
    title: 'CORNER 123 | Wholesale Women\'s Clothing',
    description: 'Wholesale women\'s fashion in the LA Fashion District',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=Inter:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-body antialiased">
        {children}
      </body>
    </html>
  )
}
