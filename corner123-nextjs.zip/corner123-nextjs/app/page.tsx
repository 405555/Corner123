import Navigation from '@/components/Navigation'
import Hero from '@/components/Hero'
import About from '@/components/About'
import Categories from '@/components/Categories'
import Gallery from '@/components/Gallery'
import WhyUs from '@/components/WhyUs'
import FAQ from '@/components/FAQ'
import Contact from '@/components/Contact'
import Footer from '@/components/Footer'

export default function Home() {
  return (
    <>
      <Navigation />
      <Hero />
      <About />
      <Categories />
      <Gallery />
      <WhyUs />
      <FAQ />
      <Contact />
      <Footer />
    </>
  )
}
