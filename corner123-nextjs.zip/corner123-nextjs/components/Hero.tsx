'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { ChevronDown } from 'lucide-react'

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  }

  return (
    <section className="relative h-screen min-h-96 flex items-end overflow-hidden pt-20">
      <Image
        src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1800&q=80&auto=format&fit=crop"
        alt="Women's fashion collection"
        fill
        className="object-cover"
        priority
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/15 via-black/5 to-black/85" />

      <motion.div
        className="relative z-10 pb-16 px-6 md:px-10 max-w-2xl"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.p variants={itemVariants} className="section-tag">
          Los Angeles Fashion District · Wholesale
        </motion.p>

        <motion.h1
          variants={itemVariants}
          className="font-display text-6xl md:text-7xl lg:text-8xl font-light text-white leading-tight mb-6"
        >
          Curated <em className="italic">Women's</em>
          <br />
          Fashion,
          <br />
          Wholesale.
        </motion.h1>

        <motion.p variants={itemVariants} className="text-base md:text-lg text-white/80 max-w-lg leading-relaxed mb-8">
          CORNER 123 brings a carefully selected range of contemporary women's clothing to wholesale buyers. Located in the heart of the LA Fashion District.
        </motion.p>

        <motion.div variants={itemVariants} className="flex gap-4 flex-wrap">
          <a href="#categories" className="btn-primary">
            Browse Collection
          </a>
          <a href="#contact" className="btn-outline">
            Contact Us
          </a>
        </motion.div>
      </motion.div>

      <motion.div
        className="absolute bottom-8 right-10 flex flex-col items-center gap-2 text-white/50 z-10"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <ChevronDown size={20} />
      </motion.div>
    </section>
  )
}
