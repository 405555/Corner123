'use client'

import { motion } from 'framer-motion'
import { Star, DollarSign, MapPin, Users, Heart, Grid3x3 } from 'lucide-react'

const features = [
  {
    icon: Star,
    title: 'Modern Fashion Selection',
    description: 'Our inventory reflects current trends, offering buyers a relevant and fresh range every season.',
  },
  {
    icon: DollarSign,
    title: 'Wholesale Pricing',
    description: 'Competitive wholesale rates structured for retailers, boutiques, and resellers of all sizes.',
  },
  {
    icon: MapPin,
    title: 'Prime LA Location',
    description: 'Situated in the Los Angeles Fashion District — a hub for wholesale buyers from across the country.',
  },
  {
    icon: Users,
    title: 'Professional Service',
    description: 'Dedicated customer service to assist buyers with selections, inquiries, and account support.',
  },
  {
    icon: Heart,
    title: 'Quality Apparel',
    description: 'Each category is curated with attention to quality, wearability, and retail-ready presentation.',
  },
  {
    icon: Grid3x3,
    title: 'Diverse Collections',
    description: 'From casual everyday wear to statement outerwear — a comprehensive range under one roof.',
  },
]

export default function WhyUs() {
  return (
    <section id="why-us" className="section-wrap bg-charcoal">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="section-tag text-accent">Why Corner 123</p>
          <h2 className="section-title text-white">
            The Right Choice for <em className="italic">Wholesale Buyers</em>
          </h2>
          <div className="section-divider mx-auto mt-6" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => {
            const Icon = feature.icon
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                viewport={{ once: true }}
                className="p-8 border border-white/7 bg-white/3 hover:border-accent hover:bg-accent/5 transition-all duration-300"
              >
                <div className="w-11 h-11 border border-accent flex items-center justify-center text-accent mb-4">
                  <Icon size={20} />
                </div>
                <h3 className="font-display text-xl font-light text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-sm text-warm-gray leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
