'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'

const galleryImages = [
  {
    src: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 1',
    tall: true,
  },
  {
    src: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 2',
  },
  {
    src: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 3',
  },
  {
    src: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 4',
    tall: true,
  },
  {
    src: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 5',
  },
  {
    src: 'https://images.unsplash.com/photo-1562157873-818bc0726f68?w=600&q=75&auto=format&fit=crop',
    alt: 'Fashion gallery 6',
  },
]

export default function Gallery() {
  return (
    <section id="gallery" className="section-wrap bg-charcoal">
      <div className="max-w-7xl mx-auto">
        <p className="section-tag text-accent">Visual Showcase</p>
        <h2 className="section-title text-white mb-4">
          The <em className="italic">Collection</em>
        </h2>
        <p className="text-sm text-warm-gray mb-12">
          All images are royalty-free placeholders. Replace with your actual product photography.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {galleryImages.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              viewport={{ once: true }}
              className={`relative overflow-hidden bg-charcoal cursor-pointer group ${
                img.tall ? 'md:row-span-2' : ''
              }`}
              style={{ aspectRatio: img.tall ? '3/5' : '4/3' }}
            >
              <Image
                src={img.src}
                alt={img.alt}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
