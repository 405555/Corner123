'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'

export default function About() {
  return (
    <section id="about" className="section-wrap">
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 md:gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="relative aspect-4/5 overflow-hidden"
        >
          <Image
            src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80&auto=format&fit=crop"
            alt="Women's clothing showroom"
            fill
            className="object-cover hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute bottom-8 left-0 -translate-x-6 bg-accent text-white p-6">
            <strong className="block font-display text-4xl font-light leading-none">LA</strong>
            <span className="text-xs uppercase tracking-widest">Fashion District</span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <p className="section-tag">Our Story</p>
          <h2 className="section-title mb-6">
            Wholesale Fashion
            <br />
            <em className="italic">At Its Best</em>
          </h2>
          <div className="section-divider" />

          <p className="text-warm-gray leading-relaxed mb-4">
            CORNER 123 is a wholesale women's clothing business based at 1329 B S Los Angeles St in the vibrant Los Angeles Fashion District — one of the world's premier destinations for fashion buyers and retailers.
          </p>

          <p className="text-warm-gray leading-relaxed mb-8">
            We carry a modern, seasonally updated selection of women's apparel spanning hoodies, jackets, dresses, tops, bottoms, and outerwear — designed to meet the diverse needs of retailers, boutiques, and resellers.
          </p>

          <div className="flex flex-col md:flex-row gap-8 pt-8 border-t border-stone">
            <div>
              <strong className="block font-display text-3xl font-light">6+</strong>
              <span className="text-xs uppercase tracking-widest text-warm-gray">Categories</span>
            </div>
            <div>
              <strong className="block font-display text-3xl font-light">24/7</strong>
              <span className="text-xs uppercase tracking-widest text-warm-gray">Open Hours</span>
            </div>
            <div>
              <strong className="block font-display text-3xl font-light">LA</strong>
              <span className="text-xs uppercase tracking-widest text-warm-gray">Fashion District</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
