'use client'

import Link from 'next/link'
import { motion } from 'framer-motion'
import { Instagram, Facebook, MessageCircle } from 'lucide-react'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-black pt-16 pb-8 px-6 md:px-10">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 pb-8 mb-8 border-b border-white/7">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <a href="#" className="font-display text-2xl font-normal tracking-widest text-white uppercase mb-4 block">
              Corner <span className="text-accent">123</span>
            </a>
            <p className="text-xs text-warm-gray leading-relaxed mb-4">
              Wholesale women's clothing in the heart of the Los Angeles Fashion District. Contemporary styles for retailers and boutiques.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 border border-white/10 flex items-center justify-center text-warm-gray hover:border-accent hover:text-accent transition-colors">
                <Instagram size={16} />
              </a>
              <a href="#" className="w-9 h-9 border border-white/10 flex items-center justify-center text-warm-gray hover:border-accent hover:text-accent transition-colors">
                <Facebook size={16} />
              </a>
              <a href="https://wa.me/18003969254" className="w-9 h-9 border border-white/10 flex items-center justify-center text-warm-gray hover:border-accent hover:text-accent transition-colors">
                <MessageCircle size={16} />
              </a>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xs font-medium uppercase tracking-widest text-white mb-4">Quick Links</h4>
            <nav className="space-y-2">
              <a href="#about" className="block text-xs text-warm-gray hover:text-accent transition-colors">About Us</a>
              <a href="#categories" className="block text-xs text-warm-gray hover:text-accent transition-colors">Collections</a>
              <a href="#gallery" className="block text-xs text-warm-gray hover:text-accent transition-colors">Gallery</a>
              <a href="#why-us" className="block text-xs text-warm-gray hover:text-accent transition-colors">Why Choose Us</a>
              <a href="#faq" className="block text-xs text-warm-gray hover:text-accent transition-colors">FAQ</a>
            </nav>
          </motion.div>

          {/* Categories */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xs font-medium uppercase tracking-widest text-white mb-4">Categories</h4>
            <nav className="space-y-2">
              <a href="#categories" className="block text-xs text-warm-gray hover:text-accent transition-colors">Hoodies</a>
              <a href="#categories" className="block text-xs text-warm-gray hover:text-accent transition-colors">Jackets</a>
              <a href="#categories" className="block text-xs text-warm-gray hover:text-accent transition-colors">Dresses</a>
              <a href="#categories" className="block text-xs text-warm-gray hover:text-accent transition-colors">Tops</a>
            </nav>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h4 className="text-xs font-medium uppercase tracking-widest text-white mb-4">Contact</h4>
            <p className="text-xs text-warm-gray leading-relaxed mb-3">
              1329 B S Los Angeles St<br />
              Los Angeles, CA 90015
            </p>
            <a href="tel:+18003969254" className="block text-xs text-warm-gray hover:text-accent transition-colors mb-3">
              +1 (800) 396-9254
            </a>
            <p className="text-xs text-warm-gray mb-2">Open 24 Hours</p>
            <a href="https://wa.me/18003969254" className="text-xs text-warm-gray hover:text-accent transition-colors">
              Chat on WhatsApp
            </a>
          </motion.div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-warm-gray">
          <p>© {currentYear} CORNER 123. All rights reserved.</p>
          <p className="text-white/10">Website by Vercel</p>
        </div>
      </div>
    </footer>
  )
}
