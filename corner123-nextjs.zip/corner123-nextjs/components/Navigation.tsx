'use client'

import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 px-6 md:px-10 py-5 transition-all duration-400 ${
          scrolled
            ? 'bg-black/88 backdrop-blur-xl border-b border-white/6'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <a href="#" className="font-display text-2xl font-normal tracking-widest text-white uppercase">
            Corner <span className="text-accent">123</span>
          </a>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-10">
            <a href="#about" className="text-xs uppercase tracking-widest text-white/75 hover:text-white transition-colors">About</a>
            <a href="#categories" className="text-xs uppercase tracking-widest text-white/75 hover:text-white transition-colors">Collections</a>
            <a href="#gallery" className="text-xs uppercase tracking-widest text-white/75 hover:text-white transition-colors">Gallery</a>
            <a href="#why-us" className="text-xs uppercase tracking-widest text-white/75 hover:text-white transition-colors">Why Us</a>
            <a href="#faq" className="text-xs uppercase tracking-widest text-white/75 hover:text-white transition-colors">FAQ</a>
            <a href="#contact" className="btn-primary text-xs">Contact</a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-white"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black pt-24 flex flex-col items-center justify-start gap-8 md:hidden">
          <a href="#about" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">About</a>
          <a href="#categories" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">Collections</a>
          <a href="#gallery" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">Gallery</a>
          <a href="#why-us" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">Why Us</a>
          <a href="#faq" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">FAQ</a>
          <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="font-display text-3xl font-light uppercase text-white hover:text-accent transition-colors">Contact</a>
        </div>
      )}
    </>
  )
}
