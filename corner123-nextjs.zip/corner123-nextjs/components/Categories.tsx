'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'

const categories = [
  {
    name: 'Hoodies',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=600&q=75&auto=format&fit=crop',
    description: 'Comfortable everyday styles in a variety of colors and fits.',
  },
  {
    name: 'Jackets',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=75&auto=format&fit=crop',
    description: 'On-trend outerwear from casual to structured silhouettes.',
  },
  {
    name: 'Dresses',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&q=75&auto=format&fit=crop',
    description: 'Elegant and casual options for every occasion and season.',
  },
  {
    name: 'Tops',
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=600&q=75&auto=format&fit=crop',
    description: 'Versatile tops in classic and contemporary styles.',
  },
  {
    name: 'Bottoms',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4a5050?w=600&q=75&auto=format&fit=crop',
    description: 'Pants, skirts, and shorts designed for the modern woman.',
  },
  {
    name: 'Outerwear',
    image: 'https://images.unsplash.com/photo-1548454782-15b189d129ab?w=600&q=75&auto=format&fit=crop',
    description: 'Coats and layers built for style through every season.',
  },
]

export default function Categories() {
  return (
    <section id="categories" className="section-wrap bg-linen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12 gap-6">
          <div>
            <p className="section-tag">Our Collection</p>
            <h2 className="section-title">
              Shop by <em className="italic">Category</em>
            </h2>
          </div>
          <a href="#contact" className="btn-primary bg-off-black hover:bg-charcoal">
            Inquire Wholesale
          </a>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
          {categories.map((cat, i) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              viewport={{ once: true }}
              className="relative aspect-3/4 overflow-hidden group cursor-pointer bg-charcoal"
            >
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                className="object-cover group-hover:scale-107 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/82 to-black/10 group-hover:from-black/90 transition-all duration-400" />

              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="font-display text-3xl font-light text-white mb-2">
                  {cat.name}
                </h3>
                <p className="text-sm text-white/60 leading-relaxed max-h-0 group-hover:max-h-20 transition-all duration-400 overflow-hidden">
                  {cat.description}
                </p>
              </div>

              <div className="absolute top-4 right-4 text-xs uppercase tracking-widest text-accent border border-accent px-3 py-1.5 bg-black/50 backdrop-blur">
                Wholesale
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
