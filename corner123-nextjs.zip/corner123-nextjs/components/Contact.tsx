'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { MapPin, Phone, Clock } from 'lucide-react'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 4000)
  }

  return (
    <section id="contact" className="section-wrap bg-charcoal">
      <div className="max-w-6xl mx-auto">
        <p className="section-tag text-accent">Get In Touch</p>
        <h2 className="section-title text-white mb-2">
          Let's <em className="italic">Connect</em>
        </h2>
        <div className="section-divider mb-12" />

        <div className="grid md:grid-cols-2 gap-12">
          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="mb-8 flex gap-4">
              <div className="w-9 h-9 border border-white/10 flex items-center justify-center text-accent flex-shrink-0">
                <MapPin size={16} />
              </div>
              <div>
                <h3 className="font-display font-light text-white mb-1">Our Address</h3>
                <p className="text-sm text-warm-gray leading-relaxed">
                  1329 B S Los Angeles St<br />
                  Los Angeles, CA 90015<br />
                  United States
                </p>
              </div>
            </div>

            <div className="mb-8 flex gap-4">
              <div className="w-9 h-9 border border-white/10 flex items-center justify-center text-accent flex-shrink-0">
                <Phone size={16} />
              </div>
              <div>
                <h3 className="font-display font-light text-white mb-1">Phone</h3>
                <a href="tel:+18003969254" className="text-sm text-warm-gray hover:text-accent transition-colors">
                  +1 (800) 396-9254
                </a>
              </div>
            </div>

            <div className="mb-8 flex gap-4">
              <div className="w-9 h-9 border border-white/10 flex items-center justify-center text-accent flex-shrink-0">
                <Clock size={16} />
              </div>
              <div>
                <h3 className="font-display font-light text-white mb-1">Business Hours</h3>
                <p className="text-sm text-warm-gray">Open 24 Hours</p>
              </div>
            </div>

            <div className="mt-12 aspect-video overflow-hidden border border-white/7">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3305.735!2d-118.2596!3d34.0373!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c772e3b70837%3A0x16e!2s1329+S+Los+Angeles+St%2C+Los+Angeles%2C+CA+90015!5e0!3m2!1sen!2sus!4v1"
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'invert(0.85) hue-rotate(180deg) saturate(0.5)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="font-display text-2xl font-light text-white mb-6">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium uppercase tracking-widest text-warm-gray mb-2">
                    First Name
                  </label>
                  <input
                    type="text"
                    placeholder="Jane"
                    className="w-full px-4 py-2 bg-white/4 border border-white/10 text-white text-sm placeholder:text-white/25 focus:border-accent focus:bg-accent/5 outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium uppercase tracking-widest text-warm-gray mb-2">
                    Last Name
                  </label>
                  <input
                    type="text"
                    placeholder="Smith"
                    className="w-full px-4 py-2 bg-white/4 border border-white/10 text-white text-sm placeholder:text-white/25 focus:border-accent focus:bg-accent/5 outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium uppercase tracking-widest text-warm-gray mb-2">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="jane@yourbusiness.com"
                  className="w-full px-4 py-2 bg-white/4 border border-white/10 text-white text-sm placeholder:text-white/25 focus:border-accent focus:bg-accent/5 outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-medium uppercase tracking-widest text-warm-gray mb-2">
                  Message
                </label>
                <textarea
                  placeholder="Tell us about your wholesale inquiry..."
                  rows={6}
                  className="w-full px-4 py-2 bg-white/4 border border-white/10 text-white text-sm placeholder:text-white/25 focus:border-accent focus:bg-accent/5 outline-none transition-colors resize-none"
                />
              </div>

              <button type="submit" className="btn-primary">
                Send Message
              </button>

              {submitted && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-sm text-accent"
                >
                  ✓ Message sent! We'll be in touch soon.
                </motion.p>
              )}
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
