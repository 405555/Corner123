'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus } from 'lucide-react'

const faqs = [
  {
    q: 'What products does CORNER 123 offer?',
    a: 'CORNER 123 offers a wide range of women\'s clothing on a wholesale basis, including hoodies, jackets, dresses, tops, bottoms, and outerwear. Our inventory is regularly updated to reflect current fashion trends.',
  },
  {
    q: 'Where is CORNER 123 located?',
    a: 'We are located at 1329 B S Los Angeles St, Los Angeles, CA 90015 — in the heart of the Los Angeles Fashion District. This area is easily accessible and well-known as a center for wholesale fashion.',
  },
  {
    q: 'How can I contact CORNER 123?',
    a: 'You can reach us by phone at +1 (800) 396-9254, or by using the contact form on this page. You are also welcome to visit us in person at our Los Angeles Fashion District location.',
  },
  {
    q: 'What are your business hours?',
    a: 'CORNER 123 is open 24 hours. Feel free to reach out or visit at any time that is convenient for you.',
  },
]

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <section id="faq" className="section-wrap bg-white">
      <div className="max-w-2xl mx-auto">
        <p className="section-tag">Common Questions</p>
        <h2 className="section-title mb-2">
          Frequently <em className="italic">Asked</em>
        </h2>
        <div className="section-divider" />

        <div className="mt-12 space-y-px">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              viewport={{ once: true }}
              className="border-b border-stone"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full py-6 px-0 flex justify-between items-center text-left hover:text-accent transition-colors"
              >
                <span className="text-base font-medium">{faq.q}</span>
                <div
                  className={`w-7 h-7 border border-stone flex items-center justify-center text-warm-gray flex-shrink-0 transition-all duration-300 ${
                    openIndex === i ? 'border-accent text-accent rotate-45' : ''
                  }`}
                >
                  <Plus size={14} />
                </div>
              </button>

              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ maxHeight: 0, opacity: 0 }}
                    animate={{ maxHeight: 200, opacity: 1 }}
                    exit={{ maxHeight: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="pb-6 text-warm-gray leading-relaxed text-sm">
                      {faq.a}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
