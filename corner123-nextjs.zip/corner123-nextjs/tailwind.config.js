/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        black: '#0a0a0a',
        'off-black': '#111111',
        charcoal: '#1c1c1c',
        'warm-gray': '#8a8480',
        stone: '#c8c2bc',
        linen: '#f5f2ee',
        white: '#fefefe',
        accent: '#b8956a',
        'accent-light': '#d4b896',
      },
      fontFamily: {
        display: ['Cormorant Garamond', 'Georgia', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
